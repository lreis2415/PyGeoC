#! /usr/bin/env python
#coding=utf-8
def main():
    """Entry point for PyGeoC"""
    from utils import *
