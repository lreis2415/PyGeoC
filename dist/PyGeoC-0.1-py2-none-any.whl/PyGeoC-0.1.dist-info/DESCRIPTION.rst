# PyGeoC
Python for GeoComputation --- easy, convenient, and efficient.

## 1.Introduction


## 2.Download and Installation

PyGeoC is developed by pure Python, and used [Wheels](http://pythonwheels.com/) to distribute on PyPI.


+ install `python2.6+`
+ install `pip`: please refer to the [installation page
](https://pip.pypa.io/en/latest/installing/)
+ install `PyGeoC`

    `pip install <path to PyGeoC .whl>/PyGeoC<version>.whl`
    e.g.,
    `pip install e:/code/PyGeoC/pygeoc-0.1.whl`

## 3.Structure

